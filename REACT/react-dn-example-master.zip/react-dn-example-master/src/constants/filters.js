export const FILTER_ALL = 'all';
export const FILTER_STARRED = 'starred';
export const FILTER_TOPVOTED = 'topvoted';
