import React from 'react';
import ReactDOM from 'react-dom';
import ShoppingCart from './ShoppingCart';

ReactDOM.render(
  <ShoppingCart headerText="SapientNitro Watch Shop"/>,
  document.getElementById('root')
);
