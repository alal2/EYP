export default [
  {
    id: 1,
    name: 'Winner Skeleton',
    price: 499.99,
    currency: 'EUR',
    image: 'http://ecx.images-amazon.com/images/I/511aLN8ht8L.jpg',
    url: 'http://www.amazon.in/Winner-Skeleton-Mechanical-Brown-Strap/dp/B01AG08IS4?tag=googinhydr18418-21&tag=googinkenshoo-21&ascsubtag=b539d19e-975c-4c0c-bdf2-d2ca599bbb32'
  },
  {
    id: 2,
    name: 'Citizen Men',
    price: 249.99,
    currency: 'EUR',
    image: 'http://ecx.images-amazon.com/images/I/81ByULB0GqL._UY679_.jpg',
    url: 'http://www.amazon.in/Citizen-AU1065-58E-Men-Analogue-Watch/dp/B00CB9A47W?tag=googinhydr18418-21&tag=googinkenshoo-21&ascsubtag=b539d19e-975c-4c0c-bdf2-d2ca599bbb32'
  },
  {
    id: 4,
    name: 'Citizen Analog',
    price: 239.99,
    currency: 'EUR',
    image: 'http://ecx.images-amazon.com/images/I/71rRz-Lvu2L._UY679_.jpg',
    url: 'http://www.amazon.in/Citizen-Analog-Black-Dial-Watch/dp/B003L5SGVG?tag=googinhydr18418-21&tag=googinkenshoo-21&ascsubtag=b539d19e-975c-4c0c-bdf2-d2ca599bbb32'
  },
  {
    id: 6,
    name: 'Armani Exchange',
    price: 119.99,
    currency: 'EUR',
    image: 'http://ecx.images-amazon.com/images/I/91eiKjszm1L._UL1500_.jpg',
    url: 'http://www.amazon.in/Armani-Exchange-Coronado-Analog-Silver/dp/B00T5KXAR6?tag=googinhydr18418-21&tag=googinkenshoo-21&ascsubtag=b539d19e-975c-4c0c-bdf2-d2ca599bbb32'
  },
  {
    id: 5,
    name: 'Citizen Unisex',
    price: 599.99,
    currency: 'EUR',
    image: 'http://ecx.images-amazon.com/images/I/91FabREdAGL._UL1500_.jpg',
    url: 'http://www.amazon.in/Citizen-BL5250-02L-Unisex-Watch-BL525002L/dp/B000EQS0WK?tag=googinhydr18418-21&tag=googinkenshoo-21&ascsubtag=b539d19e-975c-4c0c-bdf2-d2ca599bbb32'
  },
  {
    id: 3,
    name: 'Relish Analog',
    price: 149.99,
    currency: 'EUR',
    image: 'http://ecx.images-amazon.com/images/I/61hJkw4Da4L._UX522_.jpg',
    url: 'http://www.amazon.in/Relish-Analog-Round-Casual-Watches/dp/B01BUUHGV4?tag=googinhydr18418-21&tag=googinkenshoo-21&ascsubtag=b539d19e-975c-4c0c-bdf2-d2ca599bbb32'
  }
]
